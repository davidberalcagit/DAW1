import java.lang.Math;
import java.util.Scanner;
public class ejer3 {
	public static void main(String[] args) {
		Scanner teclado=new Scanner(System.in);
		int numero=teclado.nextInt();

		String arbol =tirangulo(numero);
		System.out.println("El numero de numeros consecutivos es "+numero);


	}



	/*
	Es una funcion que nos devuelve el numero de numeros consecutivo
	@param array de numeros
	@return int contador
	*/
	private static int triangulo(String numero){

		for (int i=0;i<=LIMITE;i++) {
			return(numeros*i);
		}


	}
}